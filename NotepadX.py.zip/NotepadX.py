import tkinter as tk
from tkinter import filedialog

class Notepad:
    def __init__(self, master):
        self.master = master
        master.title("NotepadX")

        # Create the text widget
        self.text = tk.Text(master)
        self.text.pack(fill=tk.BOTH, expand=True)

        # Create the menu bar
        self.menu_bar = tk.Menu(master)
        master.config(menu=self.menu_bar)

        # Create the File menu
        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.file_menu.add_command(label="New", command=self.new_file)
        self.file_menu.add_command(label="Open", command=self.open_file)
        self.file_menu.add_command(label="Save", command=self.save_file)
        self.file_menu.add_command(label="Save As", command=self.save_file_as)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.exit)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)

        # Create the Edit menu
        self.edit_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.edit_menu.add_command(label="Cut", command=self.cut)
        self.edit_menu.add_command(label="Copy", command=self.copy)
        self.edit_menu.add_command(label="Paste", command=self.paste)
        self.menu_bar.add_cascade(label="Edit", menu=self.edit_menu)

        # Set up autosave
        self.file_path = None
        self.master.after(5000, self.autosave)

    def new_file(self):
        self.text.delete("1.0", tk.END)
        self.file_path = None

    def open_file(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            with open(file_path, "r") as f:
                self.text.delete("1.0", tk.END)
                self.text.insert(tk.END, f.read())
            self.file_path = file_path

    def save_file(self):
        if self.file_path:
            with open(self.file_path, "w") as f:
                f.write(self.text.get("1.0", tk.END))
        else:
            self.save_file_as()

    def save_file_as(self):
        file_path = filedialog.asksaveasfilename()
        if file_path:
            self.file_path = file_path
            with open(file_path, "w") as f:
                f.write(self.text.get("1.0", tk.END))

    def exit(self):
        self.master.destroy()

    def cut(self):
        self.text.event_generate("<<Cut>>")

    def copy(self):
        self.text.event_generate("<<Copy>>")

    def paste(self):
        self.text.event_generate("<<Paste>>")

    def autosave(self):
        if self.file_path:
            with open(self.file_path, "w") as f:
                f.write(self.text.get("1.0", tk.END))
        self.master.after(5000, self.autosave)

root = tk.Tk()
notepad = Notepad(root)
root.mainloop()